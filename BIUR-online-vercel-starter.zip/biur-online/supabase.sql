-- Run this in Supabase SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 24),
  roblox_username text default '',
  bio text default 'BIUR community member',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Public profiles are viewable by everyone"
on public.profiles for select
using (true);

create policy "Users can create their own profile"
on public.profiles for insert
to authenticated
with check (auth.uid() = id);

create policy "Users can update their own profile"
on public.profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

-- Automatically create a public BIUR profile when someone signs up.
create or replace function public.handle_new_biur_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  chosen_username text;
begin
  chosen_username := coalesce(
    nullif(new.raw_user_meta_data ->> 'username', ''),
    'member_' || substr(new.id::text, 1, 8)
  );

  insert into public.profiles (id, username, roblox_username)
  values (
    new.id,
    chosen_username,
    coalesce(new.raw_user_meta_data ->> 'roblox_username', '')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_biur on auth.users;
create trigger on_auth_user_created_biur
after insert on auth.users
for each row execute procedure public.handle_new_biur_user();
