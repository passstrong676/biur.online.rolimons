import "./globals.css";

export const metadata = {
  title: "BIUR — Roblox Community & Item Hub",
  description: "Explore BIUR members, Roblox inventories, limiteds and collections."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
