 "use client";

import { useEffect, useMemo, useState } from "react";
import { supabase, supabaseConfigured } from "../lib/supabase";

type Member = { id?: string; username: string; roblox_username?: string; bio?: string; created_at?: string };
type RobloxItem = { assetId: number; name: string; recentAveragePrice?: number; originalPrice?: number; serialNumber?: number; assetStock?: number };

const demoMembers: Member[] = [
  { username: "BIUR_Starter", roblox_username: "Roblox", bio: "Welcome to BIUR!" },
  { username: "LimitedHunter", roblox_username: "Builderman", bio: "Collecting limiteds." },
  { username: "ClassicTrader", roblox_username: "Shedletsky", bio: "Trading and catalog exploring." }
];

export default function Home() {
  const [tab, setTab] = useState("members");
  const [members, setMembers] = useState<Member[]>(demoMembers);
  const [selected, setSelected] = useState<Member | null>(null);
  const [query, setQuery] = useState("");
  const [robloxName, setRobloxName] = useState("");
  const [items, setItems] = useState<RobloxItem[]>([]);
  const [robloxId, setRobloxId] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [sessionUser, setSessionUser] = useState<any>(null);
  const [authMode, setAuthMode] = useState<"login"|"signup"|null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [biurName, setBiurName] = useState("");
  const [linkRoblox, setLinkRoblox] = useState("");

  async function loadMembers() {
    if (!supabase) return;
    const { data, error } = await supabase.from("profiles").select("id,username,roblox_username,bio,created_at").order("created_at", { ascending: false });
    if (!error && data) setMembers(data);
    const { data: auth } = await supabase.auth.getUser();
    setSessionUser(auth.user || null);
  }

  useEffect(() => { loadMembers(); }, []);

  const filtered = useMemo(() => members.filter(m => `${m.username} ${m.roblox_username || ""}`.toLowerCase().includes(query.toLowerCase())), [members, query]);

  async function authenticate() {
    if (!supabase) { setNotice("Connect Supabase to enable real BIUR accounts. See SETUP.md."); return; }
    setBusy(true); setNotice("");
    if (authMode === "signup") {
      const { data, error } = await supabase.auth.signUp({
        email, password,
        options: { data: { username: biurName.trim(), roblox_username: linkRoblox.trim() } }
      });
      if (error) setNotice(error.message);
      else if (data.user) {
        setNotice("Account created! Check your email if confirmation is enabled. Your BIUR profile is created automatically.");
        setAuthMode(null);
        await loadMembers();
      }
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setNotice(error.message);
      else { setAuthMode(null); await loadMembers(); setNotice("You're signed in."); }
    }
    setBusy(false);
  }

  async function logout() {
    if (!supabase) return;
    await supabase.auth.signOut(); setSessionUser(null); setNotice("Signed out.");
  }

  async function lookupRoblox(username: string) {
    if (!username.trim()) return;
    setBusy(true); setNotice(""); setItems([]); setRobloxId(null);
    try {
      const response = await fetch(`/api/roblox?username=${encodeURIComponent(username.trim())}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not load this Roblox profile.");
      setRobloxId(data.user.id); setRobloxName(data.user.name); setItems(data.items || []);
      setTab("inventory");
    } catch (e: any) { setNotice(e.message); }
    setBusy(false);
  }

  function showMember(member: Member) {
    setSelected(member);
    setRobloxName(member.roblox_username || "");
    setItems([]);
    setRobloxId(null);
    setTab("profile");
  }

  return (
    <main className="shell">
      <header className="topbar">
        <a className="logo" href="#"><span className="logo-icon">B</span><span>BIUR<span className="dot">.</span></span></a>
        <nav><button className={tab==="members"?"nav-active":""} onClick={()=>setTab("members")}>Members</button><button className={tab==="inventory"?"nav-active":""} onClick={()=>setTab("inventory")}>Inventories</button><button className={tab==="tools"?"nav-active":""} onClick={()=>setTab("tools")}>Tools</button></nav>
        <div className="account-actions">
          {sessionUser ? <><span className="signed-in">Signed in</span><button className="btn btn-outline" onClick={logout}>Log out</button></> : <><button className="btn btn-outline" onClick={()=>setAuthMode("login")}>Log in</button><button className="btn btn-primary" onClick={()=>setAuthMode("signup")}>Join BIUR <span>↗</span></button></>}
        </div>
      </header>

      <section className="hero">
        <div className="hero-content">
          <div className="eyebrow"><span className="live-dot"></span> ROBLOX COMMUNITY & ITEM HUB</div>
          <h1>Your Roblox world,<br/><span>all in one place.</span></h1>
          <p>Discover BIUR members, explore public Roblox inventories, and keep track of the items you love.</p>
          <div className="searchbar"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==="Enter"&&setTab("members")} placeholder="Search BIUR members or Roblox usernames..."/><button onClick={()=>setTab("members")}>Search</button></div>
          <div className="hero-tags"><span>✦ Member directory</span><span>◈ Public inventories</span><span>↗ Item discovery</span></div>
        </div>
        <div className="hero-visual"><div className="glow"></div><div className="orbit orbit1"></div><div className="orbit orbit2"></div><div className="showcase-card"><div className="crown">♛</div><small>BIUR COLLECTION</small><strong>COLLECT.<br/>CONNECT.<br/><em>TRADE.</em></strong><div className="card-foot"><span>YOUR ITEMS. YOUR WORLD.</span><b>✦</b></div></div><div className="floating f1">✦</div><div className="floating f2">✧</div><div className="floating f3">✦</div></div>
      </section>

      <section className="quick-stats"><div><strong>{members.length.toLocaleString()}</strong><span>BIUR members{!supabaseConfigured ? " · demo" : ""}</span></div><div><strong>PUBLIC</strong><span>Roblox inventory lookup</span></div><div><strong>ONE HUB</strong><span>Profiles & collections</span></div></section>

      <section className="workspace">
        <div className="section-heading"><div><div className="eyebrow">EXPLORE BIUR</div><h2>{tab==="members"?"Community members":tab==="inventory"?"Roblox inventory":tab==="tools"?"Trading tools":"Member profile"}</h2></div><div className="tabs"><button className={tab==="members"?"tab-active":""} onClick={()=>setTab("members")}>Members</button><button className={tab==="inventory"?"tab-active":""} onClick={()=>setTab("inventory")}>Inventory</button><button className={tab==="tools"?"tab-active":""} onClick={()=>setTab("tools")}>Tools</button></div></div>

        {notice && <div className="notice">{notice}<button onClick={()=>setNotice("")}>×</button></div>}

        {tab==="members" && <div className="member-area">
          <div className="toolbar"><div><strong>BIUR directory</strong><span>{filtered.length} members found</span></div><input className="small-search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Filter members..."/></div>
          <div className="member-grid">{filtered.map((m,i)=><button className="member-card" key={m.id||m.username} onClick={()=>showMember(m)}><div className="member-avatar">{m.username.slice(0,1).toUpperCase()}</div><div className="member-info"><strong>{m.username}</strong><span>@{m.roblox_username || "Roblox account not linked"}</span><small>{m.bio || "BIUR community member"}</small></div><span className="arrow">↗</span></button>)}</div>
          {!supabaseConfigured && <div className="setup-hint">You're viewing preview members. Connect Supabase to show everyone who registers on BIUR.</div>}
          {supabaseConfigured && filtered.length===0 && <div className="empty">No members found. Try another search.</div>}
        </div>}

        {tab==="profile" && <div className="profile-panel"><button className="back" onClick={()=>setTab("members")}>← Back to members</button><div className="profile-top"><div className="profile-avatar">{(selected?.username||"?").slice(0,1).toUpperCase()}</div><div><div className="eyebrow">BIUR MEMBER</div><h3>{selected?.username}</h3><p>@{selected?.roblox_username || "No Roblox username linked"}</p></div></div><p className="profile-bio">{selected?.bio || "This member hasn't added a bio yet."}</p>{selected?.roblox_username ? <button className="btn btn-primary" onClick={()=>lookupRoblox(selected.roblox_username!)}>View Roblox inventory ↗</button> : <div className="setup-hint">This member hasn't linked a Roblox username yet.</div>}</div>}

        {tab==="inventory" && <div className="inventory-area"><div className="inventory-search"><div><strong>Public Roblox inventory</strong><span>Look up a Roblox username to view public collectibles.</span></div><div className="lookup"><input value={robloxName} onChange={e=>setRobloxName(e.target.value)} onKeyDown={e=>e.key==="Enter"&&lookupRoblox(robloxName)} placeholder="Roblox username"/><button className="btn btn-primary" disabled={busy} onClick={()=>lookupRoblox(robloxName)}>{busy?"Loading...":"Find inventory"}</button></div></div>{robloxId && <div className="inventory-user"><span className="member-avatar">{robloxName.slice(0,1).toUpperCase()}</span><div><strong>{robloxName}</strong><span>Roblox user ID: {robloxId}</span></div></div>}{items.length>0 ? <div className="item-grid">{items.map(item=><div className="item-card" key={item.assetId}><div className="item-image"><img src={`https://www.roblox.com/asset-thumbnail/image?assetId=${item.assetId}&width=150&height=150&format=png`} alt="" onError={e=>{(e.currentTarget as HTMLImageElement).style.display="none"}}/></div><strong>{item.name}</strong><span>Asset ID: {item.assetId}</span>{item.recentAveragePrice ? <small>RAP: {item.recentAveragePrice.toLocaleString()} Robux</small>:<small>Collectible</small>}</div>)}</div> : robloxId ? <div className="empty">No public collectibles were returned for this account. The inventory may be private or have no collectibles.</div> : <div className="inventory-empty"><div className="empty-icon">▧</div><h3>Look up a Roblox collection</h3><p>Enter a Roblox username above. BIUR will try to load publicly accessible collectible items.</p></div>}</div>}

        {tab==="tools" && <div className="tools-grid"><div className="tool-card"><div className="tool-icon">⇄</div><h3>Trade comparison</h3><p>Compare item values side by side. Value data can be added as BIUR builds its item database.</p><span className="coming">VALUE DATA SETUP NEEDED</span></div><div className="tool-card"><div className="tool-icon">⌕</div><h3>Item finder</h3><p>Search the Roblox catalog by item name or asset ID. Catalog search integration is the next step.</p><span className="coming">COMING NEXT</span></div><div className="tool-card"><div className="tool-icon">♡</div><h3>Favorites</h3><p>Save items and collections to your BIUR profile once your account database is connected.</p><span className="coming">ACCOUNT REQUIRED</span></div></div>}
      </section>

      <footer id="about"><a className="logo" href="#"><span className="logo-icon">B</span><span>BIUR<span className="dot">.</span></span></a><p>Made for the Roblox community. BIUR is an independent fan project and is not affiliated with Roblox Corporation.</p><span>© 2026 BIUR</span></footer>

      {authMode && <div className="modal-backdrop" onClick={()=>setAuthMode(null)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setAuthMode(null)}>×</button><div className="eyebrow">WELCOME TO BIUR</div><h2>{authMode==="signup"?"Create your account":"Welcome back"}</h2><p>{authMode==="signup"?"Join the community and create your member profile.":"Log in to your BIUR account."}</p>{authMode==="signup" && <><label>BIUR username</label><input value={biurName} onChange={e=>setBiurName(e.target.value)} placeholder="Choose a BIUR username"/><label>Roblox username (optional)</label><input value={linkRoblox} onChange={e=>setLinkRoblox(e.target.value)} placeholder="Your Roblox username"/></>}<label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/><button className="btn btn-primary modal-submit" disabled={busy} onClick={authenticate}>{busy?"Please wait...":authMode==="signup"?"Create account":"Log in"}</button><button className="switch-auth" onClick={()=>setAuthMode(authMode==="signup"?"login":"signup")}>{authMode==="signup"?"Already have an account? Log in":"Need an account? Sign up"}</button>{!supabaseConfigured && <div className="modal-help">Account creation activates after Supabase is connected. Follow SETUP.md.</div>}</div></div>}
    </main>
  );
}
