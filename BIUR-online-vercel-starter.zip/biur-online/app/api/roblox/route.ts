import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const username = (searchParams.get("username") || "").trim();
  if (!username || username.length > 50) {
    return NextResponse.json({ error: "Enter a valid Roblox username." }, { status: 400 });
  }

  try {
    const userResponse = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usernames: [username], excludeBannedUsers: true }),
      cache: "no-store"
    });
    if (!userResponse.ok) throw new Error("Roblox user lookup is temporarily unavailable.");
    const userData = await userResponse.json();
    const user = userData.data?.[0];
    if (!user) return NextResponse.json({ error: "Roblox user not found." }, { status: 404 });

    const inventoryResponse = await fetch(
      `https://inventory.roblox.com/v1/users/${user.id}/assets/collectibles?sortOrder=Asc&limit=100`,
      { headers: { "Accept": "application/json" }, cache: "no-store" }
    );

    if (inventoryResponse.status === 403) {
      return NextResponse.json({ user: { id: user.id, name: user.name }, items: [], private: true });
    }
    if (!inventoryResponse.ok) throw new Error("Roblox did not return inventory data. Try again later.");
    const inventoryData = await inventoryResponse.json();
    const items = (inventoryData.data || []).map((item: any) => ({
      assetId: item.assetId,
      name: item.name,
      recentAveragePrice: item.recentAveragePrice,
      originalPrice: item.originalPrice,
      serialNumber: item.serialNumber,
      assetStock: item.assetStock
    }));
    return NextResponse.json({ user: { id: user.id, name: user.name }, items, nextPageCursor: inventoryData.nextPageCursor || null });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Unable to contact Roblox." }, { status: 502 });
  }
}
