# BIUR.online — setup and deployment

This is a Next.js starter for a BIUR community directory and public Roblox collectible inventory viewer.

## 1. Run it locally
1. Install Node.js 20 or newer.
2. Extract this project.
3. Open a terminal in the project folder.
4. Run `npm install`
5. Copy `.env.example` to `.env.local`.
6. Run `npm run dev` and open http://localhost:3000.

The site has a preview mode before Supabase is connected. Preview members are examples, not real BIUR users.

## 2. Enable real BIUR accounts and member directory
1. Create a project at https://supabase.com/.
2. In Supabase, open **SQL Editor** and run the contents of `supabase.sql`.
3. Open **Project Settings → API** and copy the Project URL and anon/public key.
4. Put them in `.env.local`:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
5. Restart the dev server.

Supabase Auth handles account registration and login. The `profiles` table stores BIUR usernames and optional Roblox usernames. The Members page lists registered BIUR profiles. Do not put a Supabase service-role key in the browser or in a `NEXT_PUBLIC_` variable.

For production, configure the Supabase Auth email redirect URL to your deployed domain, for example `https://biur.online/**`, and add the deployed URL to Supabase's allowed redirect URLs.

## 3. Deploy to Vercel
1. Create a GitHub repository and upload the extracted project files.
2. Sign in at https://vercel.com/ and choose **Add New → Project**.
3. Import the GitHub repository. Vercel should detect Next.js automatically.
4. In Vercel Project → Settings → Environment Variables, add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
5. Deploy.
6. To use `biur.online`, open the Vercel project's **Settings → Domains**, add `biur.online`, then follow the DNS records Vercel shows at your domain registrar.

I cannot publish to your Vercel account or change your domain DNS from this project; you must sign in and complete those steps.

## 4. Roblox inventory notes
The `/api/roblox` route resolves a Roblox username and requests up to 100 public collectible inventory entries. Roblox can return private/forbidden inventory responses, rate-limit requests, or change its API. The site does not bypass privacy settings. This starter currently shows collectibles, not every ordinary catalog item or a complete Roblox account history.

## 5. Important next steps before opening to everyone
- Add server-side validation and username uniqueness constraints if you change the profile flow.
- Add moderation, reporting, account deletion and support pages.
- Add pagination and caching for larger inventories.
- Build a verified item-value source before publishing RAP/value estimates or trade ratings.
- Add rate limiting and abuse protection to public API routes.
- Add a proper admin role enforced by database policies/server-side checks. A hidden button or client-side username check is not security.

## Brand and affiliation
BIUR is an independent fan project and is not affiliated with Roblox Corporation. Do not ask users for Roblox passwords or session cookies. Roblox account linking should use a safe, user-authorized method.
